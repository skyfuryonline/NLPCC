#!/bin/bash

# 获取当前目录名称
dir_name=$(basename "$PWD")

# 打包并压缩所有内容（排除model文件夹）
tar czvf "${dir_name}.tar.gz" --exclude=model .

echo "压缩完成！压缩文件为: ${dir_name}.tar.gz"